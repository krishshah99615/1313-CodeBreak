package com.snow.votecoin;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PollsAdapter extends RecyclerView.Adapter<PollsAdapter.MyViewHolder> {

    private List<Poll> pollsList;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView title, percent, count;

        public MyViewHolder(View view) {
            super(view);
            title = (TextView) view.findViewById(R.id.pollName);
            percent = (TextView) view.findViewById(R.id.pollPercentage);
            count = (TextView) view.findViewById(R.id.pollCount);
        }
    }


    public PollsAdapter(List<Poll> pollsList) {
        this.pollsList = pollsList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.poll_items, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Poll poll = pollsList.get(position);
        holder.title.setText(poll.getTitle());
        holder.percent.setText(poll.getPercent());
        holder.count.setText(poll.getVote());
    }

    @Override
    public int getItemCount() {
        return pollsList.size();
    }
}
