package com.snow.votecoin;

public class Poll {
        private String title, percent, vote;

        public Poll(String title, String percent, String vote) {
            this.title = title;
            this.percent = percent;
            this.vote = vote;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String name) {
            this.title = name;
        }

        public String getVote() {
            return vote;
        }

        public void setVote(String vote) {
            this.vote = vote;
        }

        public String getPercent() {
            return percent;
        }

        public void setPercent(String percent) {
            this.percent = percent;
        }
}
