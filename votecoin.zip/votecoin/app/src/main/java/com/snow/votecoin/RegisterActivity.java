package com.snow.votecoin;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.util.ArrayMap;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{

    ImageView btnScanBarcode;
    TextInputEditText aadhartxt,votertxt,passtxt;
    ProgressBar progress_bar;
    FloatingActionButton fab;
    View parent_view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        aadhartxt = (TextInputEditText) findViewById(R.id.aadhar);
        votertxt = (TextInputEditText) findViewById(R.id.voter);
        passtxt = (TextInputEditText) findViewById(R.id.pass);
        fab = (FloatingActionButton) findViewById(R.id.fab);
        parent_view = findViewById(android.R.id.content);
        progress_bar = (ProgressBar) findViewById(R.id.progress_bar);
        initViews();

        fab.setOnClickListener(this);
    }

    private void initViews() {
        btnScanBarcode = (ImageView) findViewById(R.id.barcode);
        btnScanBarcode.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.barcode:
                Intent intent = new Intent(RegisterActivity.this,ScannedBarcodeActivity.class);
                startActivityForResult(intent, 2);
                break;
            case R.id.fab:
                Signup();
                break;
        }

    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {

        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode == 2)
        {
            String barcode=intent.getStringExtra("barcode");
//            Toast.makeText(getApplicationContext(),barcode, Toast.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(),"QR code scan successful", Toast.LENGTH_LONG).show();
            processScannedData(barcode);
        }

    }

    protected void processScannedData(String scanData){
        XmlPullParserFactory pullParserFactory;

        try {
            // init the parserfactory
            JSONObject obj = new JSONObject();

            pullParserFactory = XmlPullParserFactory.newInstance();
            // get the parser
            XmlPullParser parser = pullParserFactory.newPullParser();

            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(new StringReader(scanData));

            // parse the XML
            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if(eventType == XmlPullParser.START_DOCUMENT) {
                } else if(eventType == XmlPullParser.START_TAG && DataAttributes.AADHAAR_DATA_TAG.equals(parser.getName())) {
                    // extract data from tag
                    //uid
                    aadhartxt.setText(parser.getAttributeValue(null,DataAttributes.AADHAR_UID_ATTR));
//                    obj.put("uid",parser.getAttributeValue(null,DataAttributes.AADHAR_UID_ATTR));
//                    //name
//                    obj.put("name ", parser.getAttributeValue(null,DataAttributes.AADHAR_NAME_ATTR));
//                    //gender
//                    obj.put("gender ", parser.getAttributeValue(null,DataAttributes.AADHAR_GENDER_ATTR));
//                    // year of birth
//                    obj.put("yearOfBirth ", parser.getAttributeValue(null,DataAttributes.AADHAR_YOB_ATTR));
//                    // care of
//                    obj.put("careOf ", parser.getAttributeValue(null,DataAttributes.AADHAR_CO_ATTR));
//                    // village Tehsil
//                    obj.put("villageTehsil ", parser.getAttributeValue(null,DataAttributes.AADHAR_VTC_ATTR));
//                    // Post Office
//                    obj.put("postOffice ", parser.getAttributeValue(null,DataAttributes.AADHAR_PO_ATTR));
//                    // district
//                    obj.put("district ", parser.getAttributeValue(null,DataAttributes.AADHAR_DIST_ATTR));
//                    // state
//                    obj.put("state ", parser.getAttributeValue(null,DataAttributes.AADHAR_STATE_ATTR));
//                    // Post Code
//                    obj.put("postCode ", parser.getAttributeValue(null,DataAttributes.AADHAR_PC_ATTR));

                }

                // update eventType
                eventType = parser.next();
            }

            // display the data on screen
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void Signup() {
        progress_bar.setVisibility(View.VISIBLE);
        fab.setAlpha(0f);
        final String aadhar = aadhartxt.getText().toString().trim();
        final String voter = votertxt.getText().toString().trim();
        final String pass = passtxt.getText().toString().trim();

        Map<String, Object> obj = new ArrayMap<>();
        obj.put("aadhar", aadhar);
        obj.put("voter", voter);
        obj.put("pass", pass);

        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.POST,
                Constants.URL_SIGNUP,new JSONObject(obj),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        progress_bar.setVisibility(View.GONE);
                        fab.setAlpha(1f);
                        try {
                            if (!response.getBoolean("error")) {
                                Snackbar.make(parent_view, "Login Successful", Snackbar.LENGTH_SHORT).show();
                                finish();
                                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                            }else {
                                Toast.makeText(getApplicationContext(), response.getString("err_msg"), Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progress_bar.setVisibility(View.GONE);
                        fab.setAlpha(1f);
                        Toast.makeText(getApplicationContext(), error.getMessage()+"Something went wrong", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("ctoken", Constants.ctoken);
                return headers;
            }
        };

        RequestHandler.getInstance(this).addToRequestQueue(objectRequest);
    }
}
