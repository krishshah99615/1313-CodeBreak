package com.snow.votecoin;

public class Constants {

    private static final String ROOT_URL_BCC = "http://172.22.120.132:8080/";
    private static final String ROOT_URL_BC = "http://172.22.120.132:5000/";

    public static final String URL_LOGIN = ROOT_URL_BCC + "login";
    public static final String URL_SIGNUP = ROOT_URL_BCC + "register";

    public static final String URL_TRANSACT_SIGN = ROOT_URL_BCC + "generate/transaction";

    public static final String URL_NEW_TRANSACT = ROOT_URL_BC + "transactions/new";


//    public static final String URL_VERIFY = ROOT_URL + "activate/";


    public static final String ctoken = "7d30b7c668b247beb9f7e42ee2c85b8b";

}

