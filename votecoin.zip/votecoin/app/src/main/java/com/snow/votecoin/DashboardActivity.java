package com.snow.votecoin;

import android.content.Intent;
import android.os.Bundle;

import android.graphics.Color;
import android.util.ArrayMap;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class DashboardActivity extends AppCompatActivity {

    PieChart pieChart;
    PieData pieData;
    PieDataSet pieDataSet;
    ArrayList pieEntries = new ArrayList<>();;
    ArrayList PieEntryLabels;
    RecyclerView recyclerView;
    List<Poll> pollList = new ArrayList<>();
    PollsAdapter mAdapter;
    TextView expenseTotal;
    FloatingActionButton refresh, vote,logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //enable full screen
        setContentView(R.layout.activity_dashboard);

        expenseTotal = (TextView) findViewById(R.id.expenseTotal);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);

        refresh = (FloatingActionButton) findViewById(R.id.fabrefresh);
        logout = (FloatingActionButton) findViewById(R.id.fablogout);
        vote  = (FloatingActionButton) findViewById(R.id.fabSave);

        pieChart = (PieChart) findViewById(R.id.piechart);
        pieChart.setHoleRadius(95.0f);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawSliceText(false);

        pollList = new ArrayList<Poll>();
        pieEntries = new ArrayList<>();

        mAdapter = new PollsAdapter(pollList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        Signin();
//        getEntries();


        pieDataSet = new PieDataSet(pieEntries, "");
        pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
        pieDataSet.setSliceSpace(2f);
        pieData.setDrawValues(false);

        vote.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),VotingActivity.class));
            }
        });

        refresh.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
                startActivity(getIntent());
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SharedPrefManager.getInstance(getApplicationContext()).logout();
                startActivity(new Intent(getApplicationContext(),LoginActivity.class));
                finish();
            }
        });



//        prepareMovieData();
    }

    private void getEntries() {

        pieEntries.add(new PieEntry(2f, 0));
        pieEntries.add(new PieEntry(4f, 1));
    }


    private void prepareMovieData() {
        Poll poll = new Poll("ABC", "50.0%", "5000");
        pollList.add(poll);

        poll = new Poll("PQR", "50.0%", "15000");
        pollList.add(poll);

        mAdapter.notifyDataSetChanged();
    }

    private void Signin() {
        final String aadhar = SharedPrefManager.getInstance(this).getKeyAadhar();
        final String voter = SharedPrefManager.getInstance(this).getKeyVoter();

        Map<String, Object> obj = new ArrayMap<>();
        obj.put("aadhar", aadhar);
        obj.put("voter", voter);

        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.PUT,
                Constants.URL_LOGIN,new JSONObject(obj),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (!response.getBoolean("error")) {
                                JSONArray jsonArray = new JSONArray(response.getString("party"));
                                for(int i = 0;i<jsonArray.length();i++) {
                                    JSONObject object = jsonArray.getJSONObject(i);
                                    Poll poll = new Poll(object.getString("party"), object.getString("percent"), object.getString("balance"));
                                    pollList.add(poll);
//                                    pollList.add(new Poll(object.getString("party"), object.getString("percent"), object.getString("count")));
                                    pieEntries.add(new PieEntry((float) object.getInt("balance"), i));
//                                    Toast.makeText(getApplicationContext(),object.toString(),Toast.LENGTH_LONG).show();

                                }


                                expenseTotal.setText(response.getString("total"));
                                mAdapter.notifyDataSetChanged();

                                pieChart.notifyDataSetChanged();
                                pieChart.invalidate();


//                                final PollsAdapter mAdapter = new PollsAdapter(getApplicationContext(), pollList);
//                                recyclerView.setAdapter(mAdapter);


                            }else {
                                Toast.makeText(getApplicationContext(), response.getString("err_msg"), Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage()+"Something went wrong", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("ctoken", Constants.ctoken);
                return headers;
            }
        };

        RequestHandler.getInstance(this).addToRequestQueue(objectRequest);
    }
}
