package com.snow.votecoin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.ArrayMap;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.ebanx.swipebtn.OnActiveListener;
import com.ebanx.swipebtn.OnStateChangeListener;
import com.ebanx.swipebtn.SwipeButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class VotingActivity extends AppCompatActivity {
    ImageView hilary,trump;

    String rec_pub_key;
    SwipeButton enableButton1,enableButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voting);


        trump = (ImageView) findViewById(R.id.vote_img1);
        hilary = (ImageView) findViewById(R.id.vote_img2);

        enableButton1 = (SwipeButton) findViewById(R.id.swipe_btn1);
        enableButton1.setOnActiveListener(new OnActiveListener() {
            @Override
            public void onActive() {
                rec_pub_key = "30819f300d06092a864886f70d010101050003818d0030818902818100a3ec5d36dc9cd67dd3369a703864b896336ad600732a4ab9a179e9afebe051a4a949bec4ab18e371840c5b91028d795c94a14309acb02caceaeb00936a49a06e8d60f1049078b321ac3114bd7615a0e845d45b80348673276004587aa70f1146a067717ca1da8bdfc8ce331b64467346773c2f2f075f0795c4c17594a7feaf030203010001";
                Signtran();
            }
        });

        enableButton2 = (SwipeButton) findViewById(R.id.swipe_btn2);
        enableButton2.setOnActiveListener(new OnActiveListener() {
            @Override
            public void onActive() {
                rec_pub_key = "30819f300d06092a864886f70d010101050003818d0030818902818100a3ec5d36dc9cd67dd3369a703864b896336ad600732a4ab9a179e9afebe051a4a949bec4ab18e371840c5b91028d795c94a14309acb02caceaeb00936a49a06e8d60f1049078b321ac3114bd7615a0e845d45b80348673276004587aa70f1146a067717ca1da8bdfc8ce331b64467346773c2f2f075f0795c4c17594a7feaf030203010001";
                Signtran();
            }
        });

    }

    private void Signtran() {
        Map<String, Object> obj = new ArrayMap<>();
        obj.put("sender_address", SharedPrefManager.getInstance(this).getKeyUserPublic());
        obj.put("sender_private_key", SharedPrefManager.getInstance(this).getKeyUserPrivate());
        obj.put("recipient_address", rec_pub_key);
        obj.put("amount", 1);


        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.POST,
                Constants.URL_TRANSACT_SIGN,new JSONObject(obj),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (!response.getBoolean("error")) {
                                JSONObject object = new JSONObject(String.valueOf(response.getJSONObject("transaction")));
                                Addtran(object.getString("sender_address"),object.getString("recipient_address"),response.getString("signature"));

                            }else {
                                Toast.makeText(getApplicationContext(), response.getString("err_msg"), Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.getMessage()+"Something went wrong", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("ctoken", Constants.ctoken);
                return headers;
            }
        };

        RequestHandler.getInstance(this).addToRequestQueue(objectRequest);
    }

    private void Addtran(String sender_address,String recipient_address, String signature) {
        Map<String, Object> obj = new ArrayMap<>();
        obj.put("sender_address", sender_address);
        obj.put("signature", signature);
        obj.put("recipient_address", recipient_address);
        obj.put("amount", 1);


        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.POST,
                Constants.URL_NEW_TRANSACT,new JSONObject(obj),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            if (!response.getBoolean("error")) {
                                Toast.makeText(getApplicationContext(),response.getString("message"),Toast.LENGTH_LONG).show();

                            }else if (response.getBoolean("error")) {
                                Toast.makeText(getApplicationContext(),response.getString("message"), Toast.LENGTH_LONG).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Your vote is already recorded", Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("ctoken", Constants.ctoken);
                return headers;
            }
        };

        RequestHandler.getInstance(this).addToRequestQueue(objectRequest);
    }
}
